package com.liquorbee.updater;

import android.app.Notification;
import android.app.Activity;
import android.app.Instrumentation;
import android.app.NotificationManager;
import android.app.AlarmManager;
import android.app.job.JobScheduler;
import android.content.Context;
import android.content.Intent;
import android.widget.Button;
import android.widget.TextView;
import androidx.test.core.app.ActivityScenario;
import android.service.notification.StatusBarNotification;

import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.platform.app.InstrumentationRegistry;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.junit.Assert.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicReference;

/** Run on a disposable emulator with the original POS installed and notifications granted.
 * Synthetic releases stay in this test process; production version.txt is never changed.
 */
@RunWith(AndroidJUnit4.class)
public class UpdaterDeviceTest {
    private Context context;
    private UpdateStore store;
    private NotificationManager notifications;
    private long installed;

    @Before public void prepare() {
        context = InstrumentationRegistry.getInstrumentation().getTargetContext();
        context.getSharedPreferences("liquorbee_updater", Context.MODE_PRIVATE).edit().clear().commit();
        store = new UpdateStore(context);
        store.setMonitoring(false);
        UpdateScheduler.reconcile(context);
        notifications = context.getSystemService(NotificationManager.class);
        notifications.cancelAll();
        UpdateNotifications.createChannel(context);
        InstalledPos pos = InstalledPos.read(context);
        assertTrue("Install the original POS APK before this suite", pos.installed);
        installed = pos.code;
        assertTrue("Grant POST_NOTIFICATIONS before this suite", UpdateNotifications.enabled(context));
        store.setMonitoring(true);
    }

    @After public void clean() {
        context.stopService(new Intent(context, ScheduledCheckService.class));
        notifications.cancelAll();
        context.getSharedPreferences("liquorbee_updater", Context.MODE_PRIVATE).edit().clear().commit();
        UpdateScheduler.reconcile(context);
    }

    private ReleaseCheck release(long code) {
        return new ReleaseCheck(new PublishedVersion(code, "Build " + code), "", System.currentTimeMillis());
    }

    private StatusBarNotification[] active(int expected) throws Exception {
        for (int i = 0; i < 40; i++) {
            StatusBarNotification[] result = notifications.getActiveNotifications();
            if (result.length == expected) return result;
            Thread.sleep(50);
        }
        StatusBarNotification[] result = notifications.getActiveNotifications();
        assertEquals(expected, result.length);
        return result;
    }

    @Test public void readsOriginalPosPackageVersion() {
        InstalledPos pos = InstalledPos.read(context);
        assertEquals(20260910L, pos.code);
        assertEquals("1.2.1", pos.name);
    }

    @Test public void postsOnceAndAlertsForNewerBuildWhileOldNotificationRemains() throws Exception {
        UpdateNotifications.consider(context, release(installed + 1));
        StatusBarNotification first = active(1)[0];
        assertEquals(installed + 1, store.notifiedCode());
        assertNotNull(first.getNotification().contentIntent);
        UpdateNotifications.consider(context, release(installed + 1));
        assertEquals(first.getPostTime(), active(1)[0].getPostTime());
        UpdateNotifications.consider(context, release(installed + 2));
        for (int i = 0; i < 40 && !active(1)[0].getNotification().extras
                .getString(Notification.EXTRA_TEXT).contains(Long.toString(installed + 2)); i++) Thread.sleep(50);
        Notification newer = active(1)[0].getNotification();
        assertTrue(newer.extras.getString(Notification.EXTRA_TEXT).contains(Long.toString(installed + 2)));
        assertEquals(0, newer.flags & Notification.FLAG_ONLY_ALERT_ONCE);
        assertEquals(installed + 2, store.notifiedCode());
    }

    @Test public void laterSurvivesStoreRecreationAndCannotUndoNewerNotification() throws Exception {
        store.markNotified(installed + 2);
        new UpdateStore(context).markNotified(installed + 1);
        assertEquals(installed + 2, new UpdateStore(context).notifiedCode());
        UpdateNotifications.consider(context, release(installed + 2));
        active(0);
        UpdateNotifications.consider(context, release(installed + 3));
        active(1);
    }

    @Test public void failedCheckDoesNotClearAvailableUpdateButCurrentBuildDoes() throws Exception {
        UpdateNotifications.consider(context, release(installed + 1));
        active(1);
        ReleaseCheck failure = new ReleaseCheck(null, "Offline", System.currentTimeMillis());
        store.save(failure);
        UpdateNotifications.consider(context, failure);
        assertTrue(new UpdateStore(context).lastCheck().failed());
        active(1);
        UpdateNotifications.consider(context, release(installed));
        active(0);
    }

    @Test public void pausedMonitoringDoesNotNotifyOrKeepJob() throws Exception {
        store.setMonitoring(false);
        assertTrue(UpdateScheduler.reconcile(context));
        assertNull(context.getSystemService(JobScheduler.class).getPendingJob(UpdateScheduler.JOB_ID));
        UpdateNotifications.consider(context, release(installed + 1));
        active(0);
        assertEquals(0, store.notifiedCode());
    }

    @Test public void schedulesDailyAlarmAndRemovesLegacyHourlyJob() {
        assertTrue("Allow Alarms & reminders before this suite", UpdateScheduler.exactAllowed(context));
        assertTrue(UpdateScheduler.reconcile(context));
        long first = store.nextScheduledAt();
        assertTrue(UpdateScheduler.reconcile(context));
        JobScheduler scheduler = context.getSystemService(JobScheduler.class);
        assertNull(scheduler.getPendingJob(UpdateScheduler.JOB_ID));
        assertEquals(first, store.nextScheduledAt());
        assertEquals(10, store.dailyHour());
        assertEquals(30, store.dailyMinute());
        store.setDailyTime(14, 45);
        assertTrue(UpdateScheduler.reconcile(context));
        UpdateStore recreated = new UpdateStore(context);
        assertEquals(14, recreated.dailyHour());
        assertEquals(45, recreated.dailyMinute());
        assertEquals(DailySchedule.nextRun(System.currentTimeMillis(), 14, 45, DailySchedule.CENTRAL, 0),
                recreated.nextScheduledAt());
        store.setMonitoring(false);
        UpdateScheduler.reconcile(context);
        assertEquals(0, store.nextScheduledAt());
    }

    @Test public void staleEarlyAndDuplicateAlarmDeliveriesCannotRepeatTodaysCheck() {
        long now = System.currentTimeMillis();
        store.setNextScheduledAt(now + 1000);
        assertFalse(store.claimScheduledCheck(now + 1000, now));
        assertFalse(store.claimScheduledCheck(now - 1000, now));
        store.setNextScheduledAt(now);
        assertTrue(store.claimScheduledCheck(now, now));
        assertEquals(now, new UpdateStore(context).scheduledCheckAt());
        store.setNextScheduledAt(now + 2000);
        assertFalse(new UpdateStore(context).claimScheduledCheck(now + 2000, now + 2000));
    }

    @Test public void savingTimeRearmsTodayAndClearsEarlierDismissal() {
        long now = System.currentTimeMillis();
        store.setNextScheduledAt(now);
        assertTrue(store.claimScheduledCheck(now, now));
        store.deferDailyOpening(now);
        String oldToken = store.beginDailyAttempt(now);
        java.time.ZonedDateTime chosen = java.time.Instant.ofEpochMilli(now).atZone(
                java.time.ZoneId.of(DailySchedule.CENTRAL)).plusMinutes(5);
        store.setDailyTime(chosen.getHour(), chosen.getMinute());
        assertEquals(0, store.scheduledCheckAt());
        assertEquals(0, store.dailyShownAt());
        assertEquals(0, store.dailyAttemptAt());
        assertFalse(store.confirmDailyOpened(oldToken, now));
        assertFalse("Old delivery cannot claim a newly edited schedule", store.claimScheduledCheck(now, now));
        assertTrue(UpdateScheduler.reconcile(context));
        assertEquals(chosen.withSecond(0).withNano(0).toInstant().toEpochMilli(), new UpdateStore(context).nextScheduledAt());
        assertEquals(1, store.scheduleRevision());
    }

    @Test public void actualExactAlarmChecksHttpsInBackgroundAndSchedulesTomorrow() throws Exception {
        assertTrue(UpdateScheduler.exactAllowed(context));
        store.markNotificationExplained();
        Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
        Instrumentation.ActivityMonitor monitor = instrumentation.addMonitor(MainActivity.class.getName(), null, false);
        long when = System.currentTimeMillis() + 3000;
        store.setNextScheduledAt(when);
        context.getSystemService(AlarmManager.class).setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,
                when, UpdateScheduler.alarmIntent(context, when));
        try {
            for (int i = 0; i < 600 && (store.lastCheck() == null || store.lastCheck().checkedAt < when); i++) Thread.sleep(100);
            assertTrue("Alarm service claimed the scheduled check", store.scheduledCheckAt() >= when);
            assertNotNull("Alarm service completed the HTTPS check", store.lastCheck());
            assertFalse(store.lastCheck().error, store.lastCheck().failed());
            assertEquals(installed, store.lastCheck().published.code);
            for (int i = 0; i < 50 && store.scheduledResult() == OpeningResult.CHECKING; i++) Thread.sleep(100);
            assertEquals(OpeningResult.CURRENT, store.scheduledResult());
            assertEquals(installed, store.scheduledInstalledCode());
            assertEquals(installed, store.scheduledPublishedCode());
            assertTrue("Next daily alarm scheduled", store.nextScheduledAt() > when);
            assertFalse(DailySchedule.sameDay(when, store.nextScheduledAt(), DailySchedule.CENTRAL));
            assertNull("Current POS does not open the updater", instrumentation.waitForMonitorWithTimeout(monitor, 500));
        } finally { instrumentation.removeMonitor(monitor); }
    }

    @Test public void fetchesRealHttpsVersionFile() {
        ReleaseCheck check = new ReleaseChecker(new HttpsTextFetcher()).check();
        assertFalse(check.error, check.failed());
        assertTrue(check.published.code > 0);
        store.save(check);
        assertEquals(check.published.code, new UpdateStore(context).lastCheck().published.code);
    }

    @Test public void reviewScreenLaterAndDownloadUseCorrectBuildAndOriginalUrl() throws Exception {
        store.markNotificationExplained();
        try (ActivityScenario<MainActivity> scenario = ActivityScenario.launch(MainActivity.class)) {
            AtomicBoolean ready = new AtomicBoolean(false);
            for (int i = 0; i < 300 && !ready.get(); i++) {
                scenario.onActivity(activity -> ready.set(activity.findViewById(R.id.check_button).isEnabled()));
                Thread.sleep(100);
            }
            assertTrue("Foreground HTTPS check completed", ready.get());
            scenario.onActivity(activity -> {
                store.save(release(installed + 1));
                assertEquals("Out-of-date", ((TextView) activity.findViewById(R.id.status)).getText().toString());
            });
            Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
            AtomicReference<Intent> downloadIntent = new AtomicReference<>();
            Instrumentation.ActivityMonitor monitor = new Instrumentation.ActivityMonitor() {
                @Override public Instrumentation.ActivityResult onStartActivity(Intent intent) {
                    downloadIntent.set(intent);
                    return new Instrumentation.ActivityResult(Activity.RESULT_CANCELED, null);
                }
            };
            instrumentation.addMonitor(monitor);
            try {
                scenario.onActivity(activity -> activity.findViewById(R.id.download_button).performClick());
                assertNotNull(downloadIntent.get());
                assertEquals(Intent.ACTION_VIEW, downloadIntent.get().getAction());
                assertEquals(UpdateConfig.APK_URL, downloadIntent.get().getDataString());
                assertEquals(installed, InstalledPos.read(context).code);
            } finally { instrumentation.removeMonitor(monitor); }
            ready.set(false);
            for (int i = 0; i < 300 && !ready.get(); i++) {
                scenario.onActivity(activity -> ready.set(activity.findViewById(R.id.check_button).isEnabled()));
                Thread.sleep(100);
            }
            assertTrue(ready.get());
            scenario.onActivity(activity -> {
                store.save(release(installed + 1));
                ((Button) activity.findViewById(R.id.later_button)).performClick();
                assertEquals(installed + 1, new UpdateStore(context).notifiedCode());
                assertTrue(new UpdateStore(context).dailyShownAt() > 0);
                assertTrue(activity.isFinishing());
            });
            UpdateNotifications.consider(context, release(installed + 1));
            active(0);
        }
    }

    @Test public void notificationTapOpensReviewActivity() throws Exception {
        store.markNotificationExplained();
        UpdateNotifications.consider(context, release(installed + 1));
        Notification notification = active(1)[0].getNotification();
        Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
        Instrumentation.ActivityMonitor monitor = instrumentation.addMonitor(MainActivity.class.getName(), null, false);
        try {
            notification.contentIntent.send();
            Activity activity = instrumentation.waitForMonitorWithTimeout(monitor, 10000);
            assertNotNull("Notification opens the review screen", activity);
            assertTrue(activity instanceof MainActivity);
            instrumentation.runOnMainSync(activity::finish);
        } finally { instrumentation.removeMonitor(monitor); }
    }

    @Test public void dailyAttemptIsNotCountedUntilMatchingActivityConfirms() {
        long now = System.currentTimeMillis();
        String token = store.beginDailyAttempt(now);
        UpdateStore recreated = new UpdateStore(context);
        assertEquals(now, recreated.dailyAttemptAt());
        assertEquals(0, recreated.dailyShownAt());
        assertFalse(recreated.confirmDailyOpened("untrusted-token", now));
        assertEquals(0, recreated.dailyShownAt());
        assertTrue(recreated.confirmDailyOpened(token, now));
        assertEquals(now, new UpdateStore(context).dailyShownAt());
        assertFalse(recreated.confirmDailyOpened(token, now + 1));
    }

    @Test public void dailyAutomaticLaunchOpensAndRecordsOnlyOnce() throws Exception {
        assertTrue("Allow SYSTEM_ALERT_WINDOW before this test", DailyPrompts.launchAllowed(context));
        store.markNotificationExplained();
        store.setDailyOpening(true);
        ReleaseCheck newer = release(installed + 1);
        store.save(newer);
        Instrumentation instrumentation = InstrumentationRegistry.getInstrumentation();
        Instrumentation.ActivityMonitor monitor = instrumentation.addMonitor(MainActivity.class.getName(), null, false);
        try {
            DailyPrompts.consider(context, newer);
            Activity activity = instrumentation.waitForMonitorWithTimeout(monitor, 10000);
            assertNotNull("Automatic review launch succeeded", activity);
            instrumentation.waitForIdleSync();
            for (int i = 0; i < 100 && store.dailyShownAt() == 0; i++) Thread.sleep(100);
            assertTrue(store.dailyShownAt() > 0);
            long firstAttempt = store.dailyAttemptAt();
            DailyPrompts.consider(context, release(installed + 2));
            assertEquals("Newer builds obey the same daily cap", firstAttempt, store.dailyAttemptAt());
            instrumentation.runOnMainSync(activity::finish);
        } finally { instrumentation.removeMonitor(monitor); }
    }

    @Test public void scheduledResultSurvivesManualChecksAndTimeChanges() {
        long when = System.currentTimeMillis();
        store.setNextScheduledAt(when);
        assertTrue(store.claimScheduledCheck(when, when));
        store.recordScheduledResult(when, OpeningResult.PERMISSION_REQUIRED, installed, installed + 1);
        store.save(release(installed));
        store.setDailyTime(16, 30);
        UpdateStore recreated = new UpdateStore(context);
        assertEquals(when, recreated.scheduledResultAt());
        assertEquals(OpeningResult.PERMISSION_REQUIRED, recreated.scheduledResult());
        assertEquals(installed + 1, recreated.scheduledPublishedCode());
    }

    @Test public void confirmationCannotBeOverwrittenByPendingLaunchResult() {
        long when = System.currentTimeMillis();
        store.setNextScheduledAt(when);
        assertTrue(store.claimScheduledCheck(when, when));
        String token = store.beginDailyAttempt(when);
        assertTrue(store.confirmDailyOpened(token, when));
        store.recordScheduledResult(when, OpeningResult.OPEN_REQUESTED, installed, installed + 1);
        assertEquals(OpeningResult.OPENED, store.scheduledResult());
        assertEquals(installed + 1, store.scheduledPublishedCode());
        store.recordScheduledResult(when - 1, OpeningResult.CHECK_FAILED, 0, 0);
        assertEquals(OpeningResult.OPENED, store.scheduledResult());
        String obsolete = store.beginDailyAttempt(when + 1);
        long tomorrow = when + 86400000L;
        store.setNextScheduledAt(tomorrow);
        assertTrue(store.claimScheduledCheck(tomorrow, tomorrow));
        assertFalse("Late confirmation from an old alarm cannot consume the new day", store.confirmDailyOpened(obsolete, tomorrow));
        assertEquals(OpeningResult.CHECKING, store.scheduledResult());
    }

    @Test public void openingResultExplainsCurrentFailedDisabledAndDismissedChecks() {
        assertEquals(OpeningResult.CURRENT, DailyPrompts.consider(context, release(installed)));
        assertEquals(OpeningResult.CHECK_FAILED, DailyPrompts.consider(context, new ReleaseCheck(null, "Offline", System.currentTimeMillis())));
        store.setDailyOpening(false);
        assertEquals(OpeningResult.OPENING_DISABLED, DailyPrompts.consider(context, release(installed + 1)));
        store.setDailyOpening(true);
        store.deferDailyOpening(System.currentTimeMillis());
        assertEquals(OpeningResult.DISMISSED_TODAY, DailyPrompts.consider(context, release(installed + 1)));
    }
}
